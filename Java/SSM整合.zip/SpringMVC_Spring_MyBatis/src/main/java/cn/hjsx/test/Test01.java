package cn.hjsx.test;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cn.hjsx.mapper.UserMapper;
import cn.hjsx.pojo.User;
import cn.hjsx.service.UserService;

@RunWith(SpringJUnit4ClassRunner.class) // 创建容器(使用junit4进行测试)
@ContextConfiguration("classpath:spring/applicationContext-*.xml")
public class Test01 {
	@Autowired
	public UserMapper userMapper;

	@Autowired
	public UserService userService;

	@Test
	public void testUserMapper() {
		List<User> queryAllUser = userMapper.queryAllUser();
		for (User user : queryAllUser) {
			System.out.println(user);
		}
	}

	@Test
	public void testUserService() {
		List<User> queryAllUser = userService.queryAllUser();
		for (User user : queryAllUser) {
			System.out.println(user);
		}
	}

}
