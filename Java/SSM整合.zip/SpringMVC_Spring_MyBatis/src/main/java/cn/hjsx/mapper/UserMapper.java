package cn.hjsx.mapper;

import java.util.List;

import cn.hjsx.pojo.User;

public interface UserMapper {
	/**
	 * 查询所有的用户
	 */
	public List<User> queryAllUser();
	
	/**
	 * 根据用户id删除用户信息
	 */
	public void deleteUserById(int id);
}
